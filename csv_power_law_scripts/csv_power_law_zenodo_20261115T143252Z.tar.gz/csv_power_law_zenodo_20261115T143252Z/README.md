# CSV Framework: Power-Law Xel Lattice Simulation Package

## Directory Structure
- `scripts/`: Python modules implementing analytical pipe flow (`power_law_pipe.py`), 2D xel lattice non-Newtonian stress updates (`power_law_lattice.py`, `power_law_lattice_telemetry.py`), multi-index comparisons (`compare_power_law_indices.py`), and JSON exporters (`export_telemetry_payload.py`).
- `figures/`: High-resolution (300 DPI) velocity profiles, effective viscosity ($\eta_{\text{eff}}$) heatmaps, and multi-index damping plots.
- `telemetry/`: Raw SQLite database (`csv_telemetry.db`) and serialized JSON telemetry payloads (`power_law_telemetry_payload.json`).
- `zenodo.json`: Zenodo deposition metadata record.
